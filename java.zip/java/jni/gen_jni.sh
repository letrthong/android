javac -h . HelloWorldJNI.java
