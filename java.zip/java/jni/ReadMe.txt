https://www3.ntu.edu.sg/home/ehchua/programming/java/JavaNativeInterface.html

Step1: Run gen_jni.sh
Step2: Run build_jni.sh
Step3: Run run_jni.sh


Thong LT