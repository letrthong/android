 
import static org.junit.Assert.*;  
  
import org.junit.Test;  
 
public class TestLogic {  
  
    // @BeforeClass  
    // public static void setUpBeforeClass() throws Exception {  
    //     System.out.println("before class");  
    // }  
    // @Before  
    // public void setUp() throws Exception {  
    //     System.out.println("before");  
    // }  
    
    @Test  
    public void testFindMax() throws ClassNotFoundException{  
        new HelloWorldJNI().sayHello();
        System.out.println("test case find max");  
        
    }  

    // @After  
    // public void tearDown() throws Exception {  
    //     System.out.println("after");  
    // }  
  
    // @AfterClass  
    // public static void tearDownAfterClass() throws Exception {  
    //     System.out.println("after class");  
    // }  
   

    
}  