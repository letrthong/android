https://www.baeldung.com/jni-registernatives

https://www.baeldung.com/tag/mockito
https://www.baeldung.com/mockito-spy
https://www.javatpoint.com/mockito
https://www.vogella.com/tutorials/Mockito/article.html



https://www.baeldung.com/mockito-callbacks